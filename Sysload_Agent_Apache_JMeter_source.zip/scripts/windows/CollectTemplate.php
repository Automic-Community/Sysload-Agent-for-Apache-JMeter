<?php
echo "openagent\n";
echo "\n";

echo "plan_nb_request###".rand(0, 1000)."\n";
echo "plan_nb_ok###".rand(0, 1000)."\n";
echo "plan_nb_ko###".rand(0, 1000)."\n";
echo "plan_exec_time###".rand(0, 1000)."\n";
echo "elapsed#inst1##".rand(0, 1000)."\n";
echo "elapsed#inst2##".rand(0, 1000)."\n";
echo "responseCode#inst1##".rand(0, 1000)."\n";
echo "responseCode#inst2##".rand(0, 1000)."\n";
echo "success#inst1##".rand(0, 1000)."\n";
echo "success#inst2##".rand(0, 1000)."\n";
echo "bytes#inst1##".rand(0, 1000)."\n";
echo "bytes#inst2##".rand(0, 1000)."\n";
echo "latency#inst1##".rand(0, 1000)."\n";
echo "latency#inst2##".rand(0, 1000)."\n";
?>
