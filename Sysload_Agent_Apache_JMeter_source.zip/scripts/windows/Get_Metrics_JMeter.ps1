<#
###############
#
# Sysload Studio - Main script for Apache JMETER Custom Agent
# Script version 1.00 (February 2015)
#
###############

.DESCRIPTION 
Get Metrics - For Apache JMETER v2.11 r1554548

.PARAMETER AgentName 
	Sysload Agent Instance Name
.PARAMETER JmeterBinDir
	JMETER Home Directory
.PARAMETER JmeterProjectFilePath
	JMETER Project File Path
.PARAMETER JmeterParseResult
	JMETER Parse CSV Result Delimiter
.PARAMETER debug
	Activate debug 

.NOTES
Requirements
	Variable JAVA_HOME configured
	JMeter Binairy installed
	JMeter Configuration (File : jmeter.properties)
		jmeter.save.saveservice.output_format=csv
		jmeter.save.saveservice.label=true
		jmeter.save.saveservice.response_code=true
		jmeter.save.saveservice.successful=true
		jmeter.save.saveservice.latency=true
		jmeter.save.saveservice.bytes=true
		jmeter.save.saveservice.default_delimiter=;
		jmeter.save.saveservice.print_field_names=true
		summariser.out=true
	Project JMeter created
	
Written By: Automic France (Orsyp) - Professional Service - An Automic Company
Website:	http://www.automic.com 
#>


# ---------------
# get Arguments
# ---------------
param ($AgentName="test_JMX",$JmeterBinDir="C:\apache-jmeter-2.11\bin",$JmeterProjectFilePath="C:\TEST_PLAN.jmx",$JmeterParseResult=";",$debug=0)

# For Request 
$Request = $null
[bool]$error = $false
[int]$exit_code = 0

$AgentName = $AgentName -replace  '\s+', '';
$AgentName = $AgentName -replace  '"', '';
$JmeterResultFile= $AgentName+"_"+$(Get-Date -format yyyyMMddHHmmss)+".txt";

# For Debug
[bool]$launch_cmd = $true
#[bool]$debug = $false
[bool]$skipSampler = $false

# ----------------
# Log Parameter
# ----------------
if ($debug) {
	$LogFile=".\Log_Debug_JMETER_$AgentName.log"
	if (Test-Path $LogFile) { clear-content $LogFile } # erase debug file
	add-content $LogFile "`n$((get-date).toUniversalTime()) ==> START "
	
	# JMeter Cmd Plan result
	$myJMeterResumecmdfile = ".\Log_Debug_JMETER_"+$AgentName+"_Plan_result.txt";
	if ($launch_cmd) { if (Test-Path $myJMeterResumecmdfile) { Clear-Content $myJMeterResumecmdfile } }
	
	# JMeter All request result Custom for Debug
	$JmeterResultFile= "Log_Debug_JMETER_"+$AgentName+"_All_requests_result.txt";
	if ($launch_cmd) { if (Test-Path $JmeterResultFile) { Remove-Item $JmeterResultFile } }
}

# ----------------
# Functions
# ----------------

<#
[int] 	32-bit signed integer
[long] 	64-bit signed integer
[string] 	Fixed-length string of Unicode characters
[char] 	A Unicode 16-bit character
[byte] 	An 8-bit unsigned character
[bool] 	Boolean True/False value
[decimal] 	An 128-bit decimal value
[single] 	Single-precision 32-bit floating point number
[double] 	Double-precision 64-bit floating point number
[xml] 	Xml object
[array] 	An array of values
[hashtable] 	Hashtable object
#>

function logDebug { add-content $LogFile "$((get-date).toUniversalTime()) : $args"; }
function printOpenagent { Write-host "openagent"; Write-host ""; }
function getMetricValue { 
	Param ([string]$pattern, [bool]$withInstance =$false, [bool]$customInstance=$false, [string]$instance_custom ="", [bool]$checkSuccessValue =$false, [string]$successValue =""); 
	if ($withInstance) { 
		if ($checkSuccessValue) {
			$Request | %{ if ($_ -imatch $pattern) { if ($debug) { logDebug '===> METRIC with dyn instance ===> ' $metric ' - Instance: ' ($matches[1] -replace '\s+$', '') ' - tempvalue: ' $matches[2]; } $instance = $matches[1] -replace '\s+$', ''; if ( $matches[2] -match $successValue ) { printMetric $metric $instance.ToUpper() 1 } else { printMetric $metric $instance.ToUpper() 0 } } }
		} else {
			$Request | %{ if ($_ -imatch $pattern) { if ($debug) { logDebug '===> METRIC with dyn instance ===> ' $metric ' - Instance: ' ($matches[1] -replace '\s+$', '') ' - tempvalue: ' $matches[2]; } $instance = $matches[1] -replace '\s+$', ''; printMetric $metric $instance.ToUpper() $matches[2] } }
		}
	} elseif ($customInstance) {
		if ($checkSuccessValue) { 
			$Request | %{ if ($_ -imatch $pattern) { if ($debug) { logDebug '===> METRIC with custom instance ===> ' $metric ' - tempvalue: ' $matches[1]; }  if ( $matches[1] -match $successValue ) { printMetric $metric $instance_custom 1 } else { printMetric $metric $instance_custom 0 } } } 
		} else {
			$Request | %{ if ($_ -imatch $pattern) { if ($debug) { logDebug '===> METRIC with custom instance ===> ' $metric ' - tempvalue: ' $matches[1]; } printMetric $metric $instance_custom $matches[1] } }
		}
	} else {
		if ($checkSuccessValue) { 
			$Request | %{ if ($_ -imatch $pattern) { if ($debug) { logDebug '===> METRIC no instance ===> ' $metric ' - tempvalue: ' $matches[1]; }  if ( $matches[1] -match $successValue ) { printMetric $metric "" 1 } else { printMetric $metric "" 0 } } } 
		} else {
			$Request | %{ if ($_ -imatch $pattern) { if ($debug) { logDebug '===> METRIC no instance ===> ' $metric ' - tempvalue: ' $matches[1]; } printMetric $metric "" $matches[1] } }
		}
	}
}
function printMetric { Param ([string]$mymetric, [string]$myinstance ="", $myvalue =-1); Write-host "$mymetric#$myinstance##$myvalue" }

function getMetricValuePlan { 
	Param ([string]$pattern, [int]$nbpattern=7); 
	
	$nb_request = 0;
	$exec_time = 0;
	[int] $nb_req_ko = 0
		
	$Request | %{ if ($_ -imatch $pattern) { $nb_request = $matches[1]; $exec_time = $matches[2]; $nb_req_ko = $matches[7]; if ($debug) { logDebug '===> METRIC PLAN ===> nb_request - tempvalue: (' $matches[1] ') -> [' $nb_request ']'; } } }
	
	# => Plan Nb Request
	$metric = $metricPrefix+"nb_request"
	if ($debug) { logDebug '===> METRIC no instance ===> ' $metric ' - tempvalue: ' $nb_request; }
	printMetric $metric "" $nb_request
    
	# => Plan execution time
	$metric = $metricPrefix+"exec_time"
	if ($debug) { logDebug '===> METRIC no instance ===> ' $metric ' - tempvalue: ' $exec_time; }
	printMetric $metric "" $exec_time
	
	# => Plan nb KO
	$metric = $metricPrefix+"nb_ko"
	if ($debug) { logDebug '===> METRIC no instance ===> ' $metric ' - tempvalue: ' $nb_req_ko; }
	printMetric $metric "" $nb_req_ko
	
	# => Plan nb OK
	$metric = $metricPrefix+"nb_ok"
	[int] $nb_req_OK = $nb_request - $nb_req_ko
	if ($debug) { logDebug '===> METRIC no instance ===> ' $metric ' - tempvalue: ' $nb_req_OK; }
	printMetric $metric "" $nb_req_OK
}

#########
# START #
#########

if ($launch_cmd) {

	# ============================ #
	# Check JAVA_HOME Env Variable #
	# ============================ #
	if ($debug) { logDebug "-> Check JAVA_HOME Env Variable" }
	if (Get-Item env:JAVA_HOME) {
		if ($debug) { logDebug "-> Env Var JAVA_HOME Found : [ $env:JAVA_HOME ]" } 
	} else {
		if ($debug) { logDebug "-> Env Var JAVA_HOME not found " }
		write "Env Var JAVA_HOME not found)"
		$exit_code = 2;
		$error=$true;
	}
	
	# ================== #
	# Check Project File #
	# ================== #
	if ($debug) { logDebug "-> Check Jmeter Project File" }
	
	if (Test-Path "$JmeterProjectFilePath") {
		if ($debug) { logDebug "-> JMeter Project File Found : My Project File = [ $JmeterProjectFilePath ]" } 
	} else {
		if ($debug) { logDebug "-> JMeter Project File not found (Need File xxx.jmx)" }
		write "JMeter binairies command not found (Need jmeter.bat)"
		$exit_code = 99;
		$error=$true;
	}	
	# ============== #
	# Launch Request #
	# ============== #
	if ($debug) { logDebug "-> Launch Request" }
	if (Test-Path "$JmeterBinDir\jmeter.bat") {
			
		$cmd = "&'$JmeterBinDir\jmeter.bat' -n -t '"+$JmeterProjectFilePath+"' -l '"+$JmeterResultFile+"' -Jsummariser.out=true"
		
		if ($debug) { logDebug "-> Invoke Request : My Command = [ $cmd ]" } 
		$Request = invoke-expression $cmd -ErrorVariable error_invoke
		if ($LASTEXITCODE -ne 0) {
			$code = $LASTEXITCODE;
			write "JMeter return FAILED code : [$code]"
			if ($debug) { logDebug "-> Invoke Request : ERROR - JMeter return FAILED code : [$code]" }
			$error=$true;
			$exit_code=$code;
			break $code;
		} else {
			if ($debug) { logDebug "-> Invoke Request : OK - JMeter return SUCCESS code" }
		} 

		if ($debug) { add-content $myJMeterResumecmdfile $Request ; logDebug "-> Result saved in : $myJMeterResumecmdfile"}
		
	} else {
		if ($debug) { logDebug "-> Launch Request : JMeter binairies command not found (Need jmeter.bat)" }
		write "JMeter binairies command not found (Need jmeter.bat)"
		$exit_code = 99;
		$error=$true;
	}
	
} else {
	if ($debug) { logDebug "-> Launch Request : Not activated " }
}

if ($error -eq $false) {

	# =============== #
	# Print openagent #
	# =============== #
	if ($debug) { logDebug "--> Print openagent" }
	printOpenagent

	# ================= #
	# Stat Plan Metrics #
	# ================= #
	
	if ($debug) { 
		logDebug "===> Start Get Statistic Plan Metric"
		if ($launch_cmd -eq $false) { $Request = Get-Content $myJMeterResumecmdfile } 
	}
	
	$Request = $Request -replace '\s+', ' ';
	if ($debug) { logDebug "===> DATA `n $Request " }
	
	#
	# summary =     82 in     9s =    9,6/s Avg:   172 Min:     1 Max:  5808 Err:     0 (0,00%)
	# summary = 154 in 85s = 1.8/s Avg: 1010 Min: 1 Max: 21197 Err: 0 (0.00%)
	# summary = 1 in 0.1s = 7.6/s Avg: 132 Min: 132 Max: 132 Err: 0 (0.00%)
	#
	
	$metricPrefix = "plan_";
	#[regex] $pattern = "^summary \= ([0-9]+) in ([0-9.]+)s = ([0-9.]+)/s Avg: ([0-9]+) Min: ([0-9]+) Max: ([0-9]+) Err: ([0-9]+) \(([0-9.]+)%\)";
	[regex] $pattern = '^summary\s+\=\s+(\d+)\s+in\s+([0-9.,]+)s\s+\=\s+([0-9.,]+)\/s\s+Avg\:\s+(\d+)\s+Min\:\s+(\d+)\s+Max:\s+(\d+)\s+Err\:\s+(\d+)';
	
	if ($Request -match $pattern) {
		getMetricValuePlan $pattern
	} else {
		if ($debug) { logDebug "-> PLAN - Pattern not matched : [$pattern]" }
		$exit_code = 3;
		$error=$true;
	}
	if ($debug) { logDebug "===> End Get Statistic Plan Metric" }
	
	if ($skipSampler) {
		if ($debug) { logDebug "-> Get Metrics JMeter Sampler : skipped " }
	} else {

	# =============================== #
	# JMeter Requests Sampler Metrics #
	# =============================== #
	
		if ($debug) { 
			logDebug "===> Start Get Requests Sampler Metric"
		}
		$AllResultRequest = import-csv $JmeterResultFile -delimiter "$JmeterParseResult"
		if ($debug) { logDebug "===> DATA `r`n$AllResultRequest " }
		
		#
		# timeStamp;elapsed;label;responseCode;responseMessage;threadName;dataType;success;bytes;Latency
		#
				
		ForEach ($row in $AllResultRequest){
			$instance = $($row.label)
			$respCode = -1
			$status = 0
			if ($($row.responseCode) -match '\d') { $respCode = $($row.responseCode); }
			if ($($row.success) -match 'true') { $status = 100; }
			
			if ($debug) { logDebug '===> METRIC with custom instance [' $instance '] ===> elapsed - tempvalue: ' $($row.elapsed); }
			if ($debug) { logDebug '===> METRIC with custom instance [' $instance '] ===> responseCode - tempvalue: ' $respCode; }
			if ($debug) { logDebug '===> METRIC with custom instance [' $instance '] ===> success - tempvalue: ' $status; }
			if ($debug) { logDebug '===> METRIC with custom instance [' $instance '] ===> bytes - tempvalue: ' $($row.bytes); }
			if ($debug) { logDebug '===> METRIC with custom instance [' $instance '] ===> latency - tempvalue: ' $($row.Latency); }
			printMetric elapsed $instance $($row.elapsed)
			printMetric responseCode $instance $respCode
			printMetric success $instance $status
			printMetric bytes $instance $($row.bytes)
			printMetric latency $instance $($row.Latency)
		}

		if ($debug) { logDebug "===> End Get Requests Sampler Metric" }
	}
}

if ($debug -eq $false) { if (Test-Path $JmeterResultFile) { Remove-Item "$JmeterResultFile" } }

exit $exit_code

########
# END  #
########





