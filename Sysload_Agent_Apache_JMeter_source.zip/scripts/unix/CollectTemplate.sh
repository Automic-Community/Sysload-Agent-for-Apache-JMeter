#!/bin/sh
MinSecValue=`date +T | awk -F":" '{print $2$3}'`

echo "openagent"
echo ""
#     metric_id # metric_instance # timestamp # metric_value
echo "plan_nb_request###1"$MinSecValue
echo "plan_nb_ok###2"$MinSecValue
echo "plan_nb_ko###3"$MinSecValue
echo "plan_exec_time###4"$MinSecValue
echo "elapsed#inst1##5"$MinSecValue
echo "elapsed#inst2##6"$MinSecValue
echo "responseCode#inst1##7"$MinSecValue
echo "responseCode#inst2##8"$MinSecValue
echo "success#inst1##9"$MinSecValue
echo "success#inst2##10"$MinSecValue
echo "bytes#inst1##11"$MinSecValue
echo "bytes#inst2##12"$MinSecValue
echo "latency#inst1##13"$MinSecValue
echo "latency#inst2##14"$MinSecValue
